#include <iostream>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
#include <string.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include <thread>
#include <sys/types.h>
#include <sys/stat.h>
#include "Framer.hpp"
#include "Parser.hpp"
#include <stdlib.h>
#include "Response.hpp"
#include <time.h>
#include <fcntl.h>
#include <sys/sendfile.h>


//given some path, checks if it escapes document root
bool doesEscapeDocRoot(char* path, const char* doc_root){
	string path_string(path);
	string doc_string(doc_root);
	if(path_string.find(doc_string) == string::npos){
		return true;
	}
	return false;

}
//“http://server:port/" should be mapped to “http://server:port/index.html"
//This function maps relative path to absolute path
//Need: check if the relative path will escape the document root.
//
bool mapURL(const char* rel_path, const char* doc_root, char *& abs_path) {
	char buf[PATH_MAX+1];
	string temp_rel(rel_path);
  string temp_root(doc_root);
  string path = temp_root + temp_rel;
	//this will give the full path to the specified rel_path
	char * full_path = realpath(path.c_str(), buf); 
	//check if the full_path exists
	if(!full_path) {
    return false;
  }
	//if the full path escapes doc root, return false
	else if(doesEscapeDocRoot(full_path, doc_root)) return false;
	//construct the file path
	else{
		//construct the file path
    abs_path = full_path;
		//strcpy(abs_path, full_path);
		return true;
	}
}

bool checkPermission(const char * pathname) {
	struct stat statbuf;
	if (stat(pathname, &statbuf) < 0) return false;
	else {

		mode_t mode = statbuf.st_mode; 

		printf("mode is %o and val %d\n", mode, mode%8);

		if (mode%8 < 4) return false;
		else return true;

	}
}

void setType(RequestType request, ResponseType &response) {

	const char* texthtml = "html";
	const char* imagejpg = "jpg";
	const char* imagepng = "png";

	if (strcmp(request.fileType.c_str(), texthtml) == 0) response.content_type = "text/html";
	else if (strcmp(request.fileType.c_str(), imagejpg) == 0) response.content_type = "image/jpeg";
	else if (strcmp(request.fileType.c_str(), imagepng) == 0) response.content_type = "image/png";

}

string generateMessage(ResponseType response, string code) {
	string message;
	message = "HTTP/1.1 ";
	message += code;
	message += '\r';
	message += '\n';

	message += "Server: Apache";
	message += '\r';
	message += '\n';

	if (response.last_modified != "") {
		message += "Last-Modified: ";
		message += response.last_modified;
		message += '\r';
		message += '\n';
	}
	if (response.content_type != "") {
		message += "Content-Type: ";
		message += response.content_type;
		message += '\r';
		message += '\n';
	}
	
	if (response.content_length != "") {
		message += "Content-Length: ";
		message += response.content_length;
		message += '\r';
		message += '\n';
	}

	message += '\r';
	message += '\n';

	return message;
}

void generateResponse(RequestType request, ResponseType &response, const char* pathname) {

	string code;

	if (response.clientError) code = "400 Client Error";
	else if (!response.fileFound) code = "404 Not Found";
	else if (!response.permission) code = "403 Forbidden";
	else {
		code = "200 OK";

		// set content_type
		setType(request, response);

		// set content_length
		struct stat statbuf;
		stat(pathname, &statbuf);
		off_t st_size = statbuf.st_size;
		response.content_length = to_string(st_size);

		response.size = st_size;

		// Set last_modified
		char last_modified[100];
		time_t rawtime;
		struct tm * timeinfo;
		time (&rawtime);
		timeinfo = localtime(&rawtime);

		strftime(last_modified, 100, "%c GMT", timeinfo);
		response.last_modified.assign((const char*)last_modified);

	}

	response.message = generateMessage(response, code);
}


void HandleTCPClientThread(int clntSocket, string doc_root) {
	printf("handling client %d\n", clntSocket);

	// set timeout so that when client doesn't send message for 5 seconds, close the connection
	struct timeval timeout;
	timeout.tv_sec = 5;
	timeout.tv_usec = 0;

	setsockopt (clntSocket, SOL_SOCKET, SO_RCVTIMEO,(char*) &timeout,sizeof(timeout));
	setsockopt (clntSocket, SOL_SOCKET, SO_SNDTIMEO,(char*) &timeout,sizeof(timeout));

	Framer framer;
	Parser parser;

	uint8_t buffer[512];
	memset(buffer, 0 ,512);

	int n;	// indicates the number of bytes received from client

	// receive message from client
	n = recv(clntSocket,buffer, 512, 0);

	if (n < 0 && errno == EWOULDBLOCK) {
		printf("closing socket due to timeout\n");
		close(clntSocket);
		return;
	}


	/* This loop receives the string until the end of stream */
	while(n > 0) {
		/* Framing */
		framer.append(buffer, n);

		/* Parsing */
		string thisMessage;
		while (framer.hasMessage()) {
			thisMessage = framer.topMessage();
			framer.popMessage();
			parser.parse(thisMessage);

			/* Handle Response */
			if (parser.request.endOfHeader) {
				RequestType request = parser.request;

				parser.resetRequest();
				ResponseType response;

				if (request.clientError) response.clientError = true;
				char* abs_path;

				if (!response.clientError) {
					response.fileFound = mapURL(request.url.c_str(), doc_root.c_str(), abs_path);
					response.permission = checkPermission(abs_path);
				}

				// Generate response based on request and file path
				generateResponse(request, response, abs_path);
				// Send response header message back to client
				send(clntSocket, response.message.c_str(), response.message.size(), 0);

				// Send response body to client
				int in_fd = open(abs_path,0);
				sendfile(clntSocket, in_fd, 0, response.size);

				// If client requested closeConnection, close the connection.
				if (request.closeConnection) {
					close(clntSocket);
					return;
				}

			}
		}

		/* check if there's more to receive */
		memset(buffer, 0 ,512);
		n = recv(clntSocket, buffer, 512, 0);

		if (n < 0 && errno == EWOULDBLOCK) {
			printf("closing socket due to timeout\n");
			close(clntSocket);
			return;
		}


	}

}

void HandleTCPClient(int clntSocket, string doc_root) {

	thread threadObj(HandleTCPClientThread, clntSocket, doc_root);
	threadObj.join();


}
