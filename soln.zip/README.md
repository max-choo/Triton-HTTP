# cse124-project1

Basic skeleton code for CSE 124's Project 1

Starter code copyright (c) 2017, 2018 George Porter.  All Rights Reserved.

## To build

make
